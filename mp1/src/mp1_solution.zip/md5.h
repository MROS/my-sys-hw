#ifndef MD5_H
#define MD5_H

#include <string>

std::string str_to_md5(char *str, size_t len);

#endif