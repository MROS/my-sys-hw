#ifndef READ_CONFIG_H
#define READ_CONFIG_H

const char* alias_to(char* directory, const char* command);

#endif