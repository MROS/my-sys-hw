#include "subcommand.h"
#include "list_file.h"
#include "md5.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <map>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <algorithm>

using std::string;
using std::vector;

// 取用上一次 commit 時僅需要知道此兩項資料
struct SimpleCommit {
	int number;
	std::map<string, string> md5_map;
};

// 進行 commit 則需要完整資料
struct Commit {
	int number;
	vector<string> new_file, modified, copied, md5;
	bool is_unchanged() const {
		return new_file.size() == 0 && modified.size() == 0 && copied.size() == 0;
	}
};


bool has_file(struct FileNames file_names, const char *file_name) {
	for (int i = 0; i < file_names.length; i++) {
		if (strcmp(file_names.names[i], file_name) == 0) {
			return true;
		}
	}
	return false;
}

SimpleCommit *get_last_commit(const char *directory) {
	struct FileNames file_names = list_file(directory);
	if (file_names.length == -1) {
		fprintf(stderr, "目錄 %s 不存在\n", directory);
		return NULL;
	}
	if (has_file(file_names, ".loser_record")) {
		// XXX: 若路徑很長，可能溢位
		char path[512];
		sprintf(path, "%s/.loser_record", directory);
		int fd = open(path, O_RDONLY);
		if (fd == -1) {
			fprintf(stderr, "開啓 .loser_record 失敗\n");
			return NULL;
		}

		// 試計算一個 commit 長度： [new_file], [modified], [copied] 一行不超過 256 + 4 + 256 + 1 字
		// 又檔案不超過 1000 個
		//  1000 * (256 + 4 + 256)
		// 試計算 MD5 可能長度：檔名長度小於 256 位元組，又一個 md5 以十六進位表示爲 32 位元組
		// 又檔案不超過 1000 個
		// 故 1000 * (256 + 1 + 32 + 1) 必無問題
		// 雜七雜八的再估 50 上去

		// 還不到 1MB
		const off_t MAX_BUFFER_SIZE = 1000 * (256 + 4 + 256 + 1) + (1000 * (256 + 1 + 32 + 1) + 1) + 50;
		char buffer[MAX_BUFFER_SIZE];

		off_t file_size = lseek(fd, 0, SEEK_END);

		off_t read_bytes = (file_size > MAX_BUFFER_SIZE) ? MAX_BUFFER_SIZE : file_size;

		lseek(fd, -read_bytes, SEEK_END);
		read(fd, buffer, read_bytes);
		close(fd);

		SimpleCommit *simple_commit = new SimpleCommit;
		// 抽出 commit 編號
		int start;
		int number;
		for (off_t i = read_bytes - 1; i >= 0; i--) {
			if (buffer[i] == '#') {
				start = i + strlen("# commit");
				break;
			}
		}
		sscanf(buffer + start, "%d", &number);

		// 抽出 md5
		for (off_t i = start; i < read_bytes; i++) {
			if (buffer[i] == ')') {
				start = i + 1;
				break;
			}
		}
		simple_commit->number = number;

		string buf_str = string(buffer + start);
		std::stringstream ss(buf_str);

		while (!ss.eof()) {
			string file_name, md5;
			ss >> file_name;
			ss >> md5;
			simple_commit->md5_map[file_name] = md5;
			// std::cout << file_name << " 的 md5 是 " << md5 << std::endl;
		}
		return simple_commit;
	} else {
		// .loser_record 不存在，當作上次 commit 沒有任何檔案
		SimpleCommit *simple_commit = new SimpleCommit;
		simple_commit->number = 0;
		return simple_commit;
	}
}

string file_to_md5(char *path) {
	int fd = open(path, O_RDONLY);
	if (fd == -1) {
		fprintf(stderr, "開啓檔案 %s 失敗", path);
	}
	int file_size = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);
	char *buf = (char *)malloc(file_size);
	read(fd, buf, file_size);
	close(fd);

	string md5 = str_to_md5(buf, file_size);

	free(buf);

	return md5;
}

std::map<string, string> *count_files_md5(const char *directory) {
	struct FileNames file_names = list_file(directory);
	if (file_names.length == -1) {
		fprintf(stderr, "目錄 %s 不存在\n", directory);
		return NULL;
	}

	// printf("目前狀態：\n");
	auto md5_map = new std::map<string, string>;
	for (int i = 0; i < file_names.length; i++) {
        if (strcmp(file_names.names[i], ".") == 0 ||
              strcmp(file_names.names[i], "..") == 0 ||
              strcmp(file_names.names[i], ".loser_record") == 0) {
		} else {
			char path[512];
			sprintf(path, "%s/%s", directory, file_names.names[i]);
			string md5 = file_to_md5(path);
			// std::cout << file_names.names[i] << " 的 md5 是 " << md5 << std::endl;
			(*md5_map)[string(file_names.names[i])] = md5;
		}
	}
	return md5_map;
}

Commit *get_commit_info(char *directory) {
	SimpleCommit *last_commit = get_last_commit(directory);
	std::map<string, string> *current_md5_map = count_files_md5(directory);
	if (last_commit == NULL || current_md5_map == NULL) {
		fprintf(stderr, "取得本次 commit 所需資訊失敗");
		return NULL;
	}
	std::map<string, string> *last_md5_map = &(last_commit->md5_map);

	Commit *commit = new Commit;

	for (auto &cur_pair : *current_md5_map) {
		// 先推入本次 Commit 結構中
		(commit->md5).push_back(cur_pair.first + " " + cur_pair.second);

		// 再計算各檔案屬性爲 [new_file] or [modified] or [copied]
		size_t count = last_md5_map->count(cur_pair.first);
		if (count == 0) {
			// 上次不存在，可能是 new_file 或 copied
			bool last_exist = false;
			for (auto &last_pair : *last_md5_map) {
				if (cur_pair.second == last_pair.second) {
					last_exist = true;
					commit->copied.push_back(last_pair.first + " => " + cur_pair.first);
					break;
				}
			}
			if (last_exist == false) {
				commit->new_file.push_back(cur_pair.first);
			}
		} else if (count == 1) {
			// 上次就存在，觀察有沒有被修改過
			if (cur_pair.second != (*last_md5_map)[cur_pair.first]) {
				commit->modified.push_back(cur_pair.first);
			}
		}
	}

	std::sort(commit->md5.begin(), commit->md5.end());
	std::sort(commit->new_file.begin(), commit->new_file.end());
	std::sort(commit->modified.begin(), commit->modified.end());
	std::sort(commit->copied.begin(), commit->copied.end());
	commit->number = last_commit->number + 1;
	
	delete last_commit;
	delete current_md5_map;
	return commit;
}

void print_one_status(int fd, const string title, const vector<string> &v) {
	write(fd, title.c_str(), strlen(title.c_str()));
	write(fd, "\n", 1);
	for (const string &str : v) {
		write(fd, str.c_str(), strlen(str.c_str()));
		write(fd, "\n", 1);
	}
}

void status(char *directory) {
	Commit *commit_info = get_commit_info(directory);
	if (commit_info == NULL) {
		fprintf(stderr, "status 擷取資訊失敗");
		return;
	}
	print_one_status(STDOUT_FILENO, string("[new_file]"), commit_info->new_file);
	print_one_status(STDOUT_FILENO, string("[modified]"), commit_info->modified);
	print_one_status(STDOUT_FILENO, string("[copied]"), commit_info->copied);
	delete commit_info;
}

void commit(char *directory) {
	struct FileNames file_names = list_file(directory);
	if (file_names.length == -1) {
		fprintf(stderr, "目錄 %s 不存在\n", directory);
		return;
	} else if (file_names.length == 2) {
		fprintf(stderr, "目錄 %s 爲空目錄\n", directory);
		// 只有 "." 跟 ".." ，爲空目錄
		return;
	} else {
		Commit *commit_info = get_commit_info(directory);
		if (commit_info->is_unchanged()) {
			// 沒有任何變化，不做任何事
			return;
		} else if (commit_info->number == 1) {
			char path[512];
			sprintf(path, "%s/.loser_record", directory);
			// 第一次 commit ，建立檔案
			int fd = open(path, O_WRONLY | O_CREAT, 0664);
			char commit_str[128]; // commit 數量不會多大
			sprintf(commit_str, "# commit %d\n", commit_info->number);
			write(fd, commit_str, strlen(commit_str));
			print_one_status(fd, string("[new_file]"), commit_info->new_file);
			print_one_status(fd, string("[modified]"), commit_info->modified);
			print_one_status(fd, string("[copied]"), commit_info->copied);
			print_one_status(fd, string("(MD5)"), commit_info->md5);
			close(fd);
		} else {
			char path[512];
			sprintf(path, "%s/.loser_record", directory);
			int fd = open(path, O_WRONLY | O_APPEND);

			// 第二次之後 commit ， commit 之間有空行
			write(fd, "\n", 1);

			char commit_str[128]; // commit 數量不會多大
			sprintf(commit_str, "# commit %d\n", commit_info->number);
			write(fd, commit_str, strlen(commit_str));
			print_one_status(fd, string("[new_file]"), commit_info->new_file);
			print_one_status(fd, string("[modified]"), commit_info->modified);
			print_one_status(fd, string("[copied]"), commit_info->copied);
			print_one_status(fd, string("(MD5)"), commit_info->md5);
			close(fd);
		}
		delete commit_info;
	}
	return;
}

void log(unsigned int number, char *directory) {
	struct FileNames file_names = list_file(directory);
	if (file_names.length == -1) {
		fprintf(stderr, "目錄 %s 不存在\n", directory);
		return;
	}
	
	// 如果有目錄，開始檢查有沒有 .loser_record
	if (has_file(file_names, ".loser_record")) {
		const size_t MAX_OUTPUT_SIZE = 1024 * 1024 * 10;
		// XXX: 若路徑很長，可能溢位
		char path[512];
		sprintf(path, "%s/.loser_record", directory);

		int fd = open(path, O_RDONLY);
		if (fd == -1) {
			fprintf(stderr, "開啓 .loser_record 失敗\n");
			return;
		}
		size_t file_size = lseek(fd, 0, SEEK_END);

		size_t read_bytes = (file_size > MAX_OUTPUT_SIZE) ? MAX_OUTPUT_SIZE : file_size;

		char *buffer = (char *)malloc(sizeof(char) * read_bytes);
		lseek(fd, -read_bytes, SEEK_END);
		read(fd, buffer, read_bytes);
		close(fd);

		unsigned int counter = 0;
		size_t last_pos = read_bytes;
		for (int i = read_bytes - 1; counter < number && i >= 0; i--) {
			if (buffer[i] == '#') {
				if (counter > 0) {
					write(STDOUT_FILENO, "\n", 1);
				}
				write(STDOUT_FILENO, buffer + i, last_pos - i);
				counter++;
				last_pos = i - 1;
			}
		}
		free(buffer);
	} else {
		// 沒有 .loser_record ，不做任何事
		return;
	}
}