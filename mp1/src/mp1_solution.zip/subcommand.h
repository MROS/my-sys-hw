#ifndef SUBCOMMAND_H
#define SUBCOMMAND_H

void status(char *directory);
void commit(char *directory);
void log(unsigned int number, char *directory);

#endif