#include "subcommand.h"
#include "md5.h"
#include "read_config.h"
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  if (argc <= 2) {
    fprintf(stderr, "用法：\n./loser status <目錄>\n./loser commit <目錄>\n./loser log <數量> <目錄>\n");
  } else if(argc >= 3) {

    const char *command = alias_to(argv[argc - 1], argv[1]);

    if (strcmp(command, "status") == 0) {

      status(argv[2]);

    } else if (strcmp(command, "commit") == 0) {

      commit(argv[2]);

    } else if (strcmp(command, "log") == 0) {

      if (argc == 3) {
        fprintf(stderr, "用法：\n./loser log <數量> <目錄>\n");
      } else {
        // TODO: 處理並非數字或非正數的狀況
        unsigned int number = atoi(argv[2]);
        log(number, argv[3]);
      }

    } else {
      fprintf(stderr, "無 %s 子指令\n", argv[1]);
    }
  }
  return 0;
}