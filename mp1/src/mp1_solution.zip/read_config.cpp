#include "read_config.h"
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

const char* STATUS_STR = "status";
const char* COMMIT_STR = "commit";
const char* LOG_STR = "log";
const char* NULL_STR = "";

const char* equal_to(const char *command) {
	if (strcmp(STATUS_STR, command) == 0) { return STATUS_STR; }
	if (strcmp(COMMIT_STR, command) == 0) { return COMMIT_STR; }
	if (strcmp(LOG_STR, command) == 0) { return LOG_STR; }
	return NULL_STR;
}

const char* alias_to(char *directory, const char* command) {

	if (equal_to(command) != NULL_STR) {
		return equal_to(command);
	}

	char path[512];
	sprintf(path, "%s/.loser_config", directory);
	FILE *f_ptr = fopen(path, "r");
	if (f_ptr == NULL) {
		return NULL_STR;
	}

	char alias[256];
	char equal_symbol[2];
	char normal_command[20];

	while(fscanf(f_ptr, "%s%s%s", alias, equal_symbol, normal_command) != EOF) {
		if (strcmp(alias, command) == 0) {
			return equal_to(normal_command);
		}
	}
	return NULL_STR;
}
