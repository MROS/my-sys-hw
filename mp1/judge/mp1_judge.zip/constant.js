module.exports = {
	STATUS_NOTHING_CHANGE: `[new_file]
[modified]
[copied]
`
}
